#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/shm.h>
#include <unistd.h>
	
/*-------------------------------------------------------------------------*/
#define TAMMAX 200
	
/*-------------------------------------------------------------------------*/
void main(int argc, char **argv){
	
	FILE *out;
	char *buffer;

	int shm1, shm2;
	int chave_shm1 = 3, chave_shm2 = 5;
	int *bytesLidos;

		
	if ( argc != 2 ){
		printf("%s <arquivo_copia>\n", argv[0]);
		exit(0);
	}

	out = fopen(argv[1], "wb");

	shm1 = shmget(chave_shm1, TAMMAX, 0);
	buffer = shmat(shm1, 0, 0);

	shm2 = shmget(chave_shm2, sizeof(int), 0);
	bytesLidos = shmat(shm2, 0, 0);

	do{

		fwrite(buffer, sizeof(char), *bytesLidos, out);

	}
	while(*bytesLidos > 0);

	shmdt(buffer);
	shmdt(bytesLidos);

	shmctl(shm1, IPC_RMID, 0);
	shmctl(shm2, IPC_RMID, 0);

	fclose(out);
 	
}	
/*-------------------------------------------------------------------------*/
