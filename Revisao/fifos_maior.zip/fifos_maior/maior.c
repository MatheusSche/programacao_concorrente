#include <stdio.h>
#include <math.h>
#include <sys/types.h>
#include <time.h>
#include <stdlib.h>

/*-------------------------------------------------------*/
int **aloca_matriz(int n, int m){
	int i;
	int **mat = (int **)malloc(sizeof(int *)*n);
	
	for (i=0;i<n;i++){
		mat[i] = (int *)malloc(sizeof(int)*m);
	}
	return(mat);
}

/*-------------------------------------------------------*/
void inicializa_matriz(int **mat, int n, int m){
	int i, j;
	
	srand(time(NULL));

	for( i=0; i<n; i++){
		for( j=0; j<m; j++){
			mat[i][j] = rand() % 100;;
		}
	}

}

/*-------------------------------------------------------*/
void escreve_matriz(int **mat, int n, int m){
	int i,j;
	
	for (i=0;i<n;i++){
		for (j=0;j<m;j++){
		    printf("% 5d ", mat[i][j]);
		}
		printf("\n");
	}
}


/*----------------------------------------------------------------------------*/
void desaloca_matriz(int **mat, int n){
	int i;
	
	for (i=0;i<n;i++){
		free(mat[i]);
	}
	free(mat);
}



/*-------------------------------------------------------*/
int maior(int **mat, int n, int m){
	int i, j, maior;

	maior = mat[0][0];
 
	for (i=0; i<n; i++){
		for (j=0; j<m; j++){
			if ( maior < mat[i][j]){
				maior = mat[i][j];
			}
		}
	}
	return(maior);
}

/*-------------------------------------------------------*/
int main(int argc, char **argv){

	int **mat;
	int n, m;

	if ( argc != 2 ){
		printf("%s < ordem da matriz>\n", argv[0]);
		exit(0);
	}
	
	n = atoi(argv[1]);

	mat = aloca_matriz(n, n);

	inicializa_matriz(mat, n, n);

	escreve_matriz(mat, n, n);

	m = maior(mat, n, n);

	printf("Maior: %d\n", m);

	desaloca_matriz(mat, n);



}
	
/*-------------------------------------------------------*/
