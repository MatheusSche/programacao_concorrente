#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/shm.h>
#include <unistd.h>
	
/*-------------------------------------------------------------------------*/
#define TAMMAX 200
	
/*-------------------------------------------------------------------------*/
void main(int argc, char **argv){
	
	FILE *in;
	char *buffer;

	int shm1, shm2;
	int chave_shm1 = 3, chave_shm2 = 5;

	int *bytesLidos;

	if ( argc != 2 ){
		printf("%s <arquivo_original>\n", argv[0]);
		exit(0);
	}

	in  = fopen(argv[1], "rb");

	shm1 = shmget(chave_shm1, TAMMAX, 0600 | IPC_CREAT);
	buffer = shmat(shm1, 0, 0);

	shm2 = shmget(chave_shm2, sizeof(int), 0600 | IPC_CREAT);
	bytesLidos = shmat(shm2, 0, 0);


	do {

		*bytesLidos = fread(buffer, sizeof(char), TAMMAX, in);		
			
	}
	while( *bytesLidos > 0);
			
	shmdt(buffer);
	shmdt(bytesLidos);

	fclose(in);

}	
/*-------------------------------------------------------------------------*/
