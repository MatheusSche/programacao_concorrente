#include <stdio.h>
#include <math.h>
#include <stdlib.h>

/*-----------------------------------------*/
#define N 10

/*-----------------------------------------*/
void gera_vetor(float vet[N]){
	int i;
	for (i=0; i<N; i++){
		vet[i] = rand()%10;
	}
}

/*-----------------------------------------*/
void escreve_vetor(float vet[N]){
	int i;
	for (i=0; i<N; i++){
		printf("%f\n", vet[i]);
	}
}
/*-----------------------------------------*/
float media_desvio_padrao(float vet[N], float *media, float *dsv){
	float soma = 0;
	float soma2 = 0;
	int i;

	for(i=0; i<N; i++){
		soma = soma + vet[i];
		soma2 = soma2 + vet[i]*vet[i];
	}


	*media = soma / N;
	*dsv = sqrt( soma2/N - *media * *media );
}
/*-----------------------------------------*/
int main(){
	float vet[N];
	float media, desvio;

	gera_vetor(vet);
	escreve_vetor(vet);

	media_desvio_padrao(vet, &media, &desvio);
	printf("Media: %f\n", media);
	printf("Desvio: %f\n", desvio);
}
