#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/*-----------------------------------------------------*/
double  pi(double n){
	double termo, p = 0;
	double i;
	for( i=1; i<=n; i++ ){
		termo = 1.0 / (2*i-1);
		if ( fmod(i,2) != 0 ){ 		
			p += termo;
		}
		else{
			p -= termo;
		} 
	}

	p *= 4;
	return(p);
}

/*-----------------------------------------------------*/
int main(int argc, char **argv){
	double ntermos;

	if ( argc != 2 ){
		printf("%s <num_termos>\n", argv[0]);
		exit(0); 
	}
	
	ntermos = atof(argv[1]);

	printf("PI= %.15f\n", pi(ntermos));
}
/*-----------------------------------------------------*/

